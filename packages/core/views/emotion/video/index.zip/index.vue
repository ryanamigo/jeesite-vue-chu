<template>
<div class="bg">
  <a-row :gutter="16" class="row"> 
   <!-- 左 -->
    <a-col :span="4">
      <!-- 顶部标题 -->
       <div style="border: 1px solid #ccc; height: 99%;  ">
         <div class="topName">
            <img id="configuration" class="infoImg" src="/js/static/image/边框1.png" style="display: block; max-width: 100%">
            <div style="position: absolute;
                        top: 50%; left:22%;
                        transform: translate(-50%, -50%);
                        color: white;
                        font-size: 20px;">
               选项配置
            </div>
         </div>
       </div>
    </a-col> 
    <!-- 中 -->
    <a-col :span="14">
      <!-- 顶部标题 -->
       <div style="border: 1px solid #ccc; height: 99%;">
         <div class="topName">
            <img id="videoImg" class="infoImg" src="/js/static/image/综合数据.png" style="display: block; max-width: 100%">
            <div style="position: absolute;
                           top: 50%; left:22%;
                           transform: translate(-50%, -50%);
                           color: white;
                           font-size: 20px;">
               视频录制   
            </div>
         </div>
       </div>
    </a-col>
    <!-- 右 -->
    <a-col :span="6">
      <!-- 顶部标题 -->
       <div style="border: 1px solid #ccc; height: 99%;">

       </div>
    </a-col>
  </a-row>
</div>
</template>

<script setup lang="ts">
import { Row, Col } from 'ant-design-vue';
const aCol = Col;
const aRow = Row;
</script>
<style scoped>
.bg{
   position: relative;
   height: calc(100vh - 100px);
   background-image: url('./win2.jpg');
   background-size: cover;
}
.row{
   height: 100%;
   padding: 5px;
}
.topName{
   position: relative;
   display: inline-block;
   width: 100%;
}
.infoImg {
    background-size: contain;
    /* 设置背景图大小为包含在div中 */
    width: 100%;
    background-position: center;
    /* 可选：设置背景图位置 */
    max-width: 100%
}
</style>
